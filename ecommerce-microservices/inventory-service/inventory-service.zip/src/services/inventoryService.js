const Inventory = require("../models/Inventory");
const inventoryRepository = require("../repositories/inventoryRepository");
const { NotFoundError } = require("../utils/errors");

class InventoryService {
  async addInventory(data) {
    // Check if inventory record already exists for the product
    const existing = await inventoryRepository.getById(data.productId);
    if (existing) {
      // If it exists, we can treat this as an update or conflict. Let's update or throw conflict.
      // We will perform an update to add the stock, which is standard for an idempotent "add stock" action,
      // or we can throw conflict. The prompt says "Add Stock" under responsibilities.
      // If a record exists, we will update the stock by adding to it. Let's make it idempotent:
      const inventory = new Inventory(existing);
      inventory.availableStock += Number(data.availableStock);
      inventory.updatedAt = new Date().toISOString();
      return await inventoryRepository.update(inventory.toJSON());
    }
    const inventory = new Inventory(data);
    return await inventoryRepository.create(inventory.toJSON());
  }

  async getInventory(productId) {
    const inventoryData = await inventoryRepository.getById(productId);
    if (!inventoryData) {
      throw new NotFoundError(`Inventory not found for product ${productId}`);
    }
    return inventoryData;
  }

  async updateInventory(productId, data) {
    const inventoryData = await inventoryRepository.getById(productId);
    if (!inventoryData) {
      throw new NotFoundError(`Inventory not found for product ${productId}`);
    }

    const inventory = new Inventory(inventoryData);
    inventory.update(data);
    
    return await inventoryRepository.update(inventory.toJSON());
  }

  async reduceStock(productId, quantity) {
    // Check existence first
    const inventoryData = await inventoryRepository.getById(productId);
    if (!inventoryData) {
      throw new NotFoundError(`Inventory not found for product ${productId}`);
    }
    
    return await inventoryRepository.reduceStock(productId, quantity);
  }

  async checkAvailability(productId, quantity) {
    const inventoryData = await inventoryRepository.getById(productId);
    if (!inventoryData) {
      return { productId, available: false, availableStock: 0 };
    }
    const available = inventoryData.availableStock >= quantity;
    return {
      productId,
      available,
      availableStock: inventoryData.availableStock,
    };
  }
}

module.exports = new InventoryService();
