const response = require("../utils/response");
const orderService = require("../services/orderService");
const orderValidator = require("../validators/orderValidator");
const { BadRequestError } = require("../utils/errors");

module.exports.handler = async (event) => {
  try {
    const method = event.httpMethod;
    const orderId = event.pathParameters?.orderId;

    switch (method) {

      // Create Order
      case "POST": {
        const body = event.body ? JSON.parse(event.body) : {};

        const validatedData =
          orderValidator.validateCreate(body);

        const result =
          await orderService.createOrder(validatedData);

        return response.success(result, 201);
      }

      // Get Order / List Orders / Track Order
      case "GET": {

        // Track Order
        if (
          event.resource &&
          event.resource.includes("track")
        ) {

          if (!orderId) {
            throw new BadRequestError(
              "Missing path parameter: orderId"
            );
          }

          const result =
            await orderService.trackOrder(orderId);

          return response.success(result, 200);
        }

        // Get Order By Id
        if (orderId) {

          const result =
            await orderService.getOrder(orderId);

          return response.success(result, 200);
        }

        // List Orders
        const userId =
          event.queryStringParameters?.userId || null;

        const result =
          await orderService.listOrders(userId);

        return response.success(result, 200);
      }

      // Cancel Order
      case "PUT": {

        if (!orderId) {
          throw new BadRequestError(
            "Missing path parameter: orderId"
          );
        }

        const result =
          await orderService.cancelOrder(orderId);

        return response.success(result, 200);
      }

      default:
        throw new BadRequestError(
          `Unsupported HTTP Method: ${method}`
        );
    }

  } catch (err) {

    console.error("Order Handler Error:", err);

    return response.error(err);
  }
};