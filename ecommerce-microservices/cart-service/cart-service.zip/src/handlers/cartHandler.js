const response = require("../utils/response");
const cartService = require("../services/cartService");
const cartValidator = require("../validators/cartValidator");
const { BadRequestError } = require("../utils/errors");

module.exports.handler = async (event) => {
  try {
    const method = event.httpMethod;

    switch (method) {
      case "POST": {
        const body = event.body ? JSON.parse(event.body) : {};

        const validatedData =
          cartValidator.validateAdd(body);

        const result =
          await cartService.addToCart(validatedData);

        return response.success(result, 201);
      }

      case "GET": {
        const cartId = event.pathParameters?.cartId;

        if (!cartId) {
          throw new BadRequestError(
            "Missing path parameter: cartId"
          );
        }

        const result =
          await cartService.getCart(cartId);

        return response.success(result, 200);
      }

      case "PUT": {
        const body = event.body ? JSON.parse(event.body) : {};

        const validatedData =
          cartValidator.validateUpdate(body);

        const result =
          await cartService.updateCart(validatedData);

        return response.success(result, 200);
      }

      case "DELETE": {
        const body = event.body ? JSON.parse(event.body) : {};

        const validatedData =
          cartValidator.validateRemove(body);

        const result =
          await cartService.removeCart(
            validatedData.cartId,
            validatedData.productId
          );

        return response.success(result, 200);
      }

      default:
        throw new BadRequestError(
          `Unsupported HTTP Method: ${method}`
        );
    }
  } catch (err) {
    console.error("Cart Handler Error:", err);

    return response.error(err);
  }
};