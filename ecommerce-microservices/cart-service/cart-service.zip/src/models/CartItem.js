class CartItem {
  constructor({
    userId,
    productId,
    quantity,
    productName,
    price,
    createdAt = null,
  }) {
    this.userId = userId;
    this.productId = productId;
    this.quantity = Number(quantity);
    this.productName = productName;
    this.price = Number(price);
    this.createdAt = createdAt || new Date().toISOString();
  }

  updateQuantity(quantity) {
    this.quantity = Number(quantity);
  }

  incrementQuantity(quantity) {
    this.quantity += Number(quantity);
  }

  toJSON() {
    return {
      userId: this.userId,
      productId: this.productId,
      quantity: this.quantity,
      productName: this.productName,
      price: this.price,
      createdAt: this.createdAt,
    };
  }
}

module.exports = CartItem;
